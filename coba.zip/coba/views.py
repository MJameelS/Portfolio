from django.shortcuts import render
from .models import Tabel

# Create your views here.

def landing(request):
    # dictionary for initial data with 
    # field names as keys
    context ={}
 
    # add the dictionary during initialization
    context["dataset"] = Tabel.objects.all()
    return render(request, "index.html", context)

