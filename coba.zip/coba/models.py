from django.db import models
from django.utils.html import mark_safe

# Create your models here.

class Tabel (models.Model):
    IdBuku = models.TextField()
    Kategori = models.CharField(max_length=200)
    NamaBuku = models.CharField(max_length=200)
    Harga = models.IntegerField()
    Stok = models.IntegerField()
    Penerbit = models.CharField(max_length=50)
    Author = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='images')



    def image_tag(self):
        return mark_safe('<img src="%s" width="100px" height="100px" />'%(self.photo.url))
    image_tag.short_description = 'Image'


class Penerbit (models.Model):
    IdPenerbit = models.TextField()
    Nama = models.CharField(max_length=200)
    Alamat = models.TextField()
    Kota = models.CharField(max_length=20)
    Telepon = models.TextField()
