from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import *

# Register your models here.

class TabelAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display = ('IdBuku', 'Kategori', 'NamaBuku', 'Harga', 'Stok', 'Penerbit', 'Author', 'image_tag')
    list_filter = ('Kategori', 'NamaBuku', 'Harga', 'Stok', 'Penerbit', 'Author')
    search_fields = ('Kategori', 'NamaBuku', 'Harga', 'Stok', 'Penerbit', 'Author')

admin.site.register(Tabel, TabelAdmin)

class PenerbitAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display = ('IdPenerbit', 'Nama', 'Alamat', 'Kota', 'Telepon')
    list_filter = ('Nama', 'Alamat', 'Kota', 'Telepon')
    search_fields = ('Nama', 'Alamat', 'Kota', 'Telepon')

admin.site.register(Penerbit, PenerbitAdmin)
